using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class BankAccount //класс для работы с балансом и кредитами
{

    public UnityAction<int> onBalanceUpdated;
    public UnityAction<CreditInfo> onCreditAdded, onCreditRemoved;

    private int balance;
    private List<CreditInfo> credits = new List<CreditInfo>();

    public void Clear()
    {
        balance = 0;
        credits.Clear();
    }

    public int GetBalance()
    {
        return balance;
    }
    
    public void Init(int balance)
    {
        SetBalance(balance);
    }
    
    //восстановление сохранённых данных
    public void Restore(int balance, List<CreditInfo> credits)
    {
        SetBalance(balance);
        if (credits != null)
        {
            this.credits = credits;
            foreach (var credit in credits)
            {
                onCreditAdded?.Invoke(credit);
            }
        }
    }
    
    public void Receive(int value)
    {
        SetBalance(balance + value);
    }
    
    public void Pay(int value)
    {
        SetBalance(balance - value);
    }
    
    public bool HasAmount(int value)
    {
        return balance >= value;
    }

    private void SetBalance(int value)
    {
        balance = value;
        onBalanceUpdated?.Invoke(balance);
    }

    public void AddCredit(int value)
    {
        CreditInfo credit = new CreditInfo(value);
        credits.Add(credit);
        onCreditAdded?.Invoke(credit);
    }

    public void RemoveCredit(CreditInfo credit)
    {
        var index = credits.FindIndex(_credit => _credit.id == credit.id);
        if (index >= 0)
        {
            onCreditRemoved?.Invoke(credit);
            credits.RemoveAt(index);
        }
    }
    
    public bool HasCredits()
    {
        return credits.Count > 0;
    }
    
    public List<CreditInfo> GetCredits()
    {
        return credits;
    }


}
