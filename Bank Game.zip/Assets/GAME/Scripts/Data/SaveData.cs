using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class SaveData
{

    public int balance;
    public List<CreditInfo> credits;
    public int day;
    public int nextMessageDay;
    public int messagesPassed;
    public int lastPensionDay, lastCreditDay;
    public int messageID;
    

    public string toJSON()
    {
        return JsonUtility.ToJson(this);
    }
    
    public static SaveData fromJSON(string json)
    {
        return JsonUtility.FromJson<SaveData>(json);
    }

}
