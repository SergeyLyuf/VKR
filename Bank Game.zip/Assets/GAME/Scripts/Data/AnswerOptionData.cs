using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class AnswerOptionData
{
    public int stealValue;
    public StealType stealType;
    public string answerText;
    

}
