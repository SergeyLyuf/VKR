using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Dialog Data", menuName = "Bank Game/New Dialog Data", order = 1)]
public class DialogData : ScriptableObject
{

    public List<MessageData> messages;

}
