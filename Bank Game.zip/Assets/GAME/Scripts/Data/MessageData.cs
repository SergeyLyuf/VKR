using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MessageData
{
    public string senderName;
    [TextArea(1, 10)] 
    public string message;
    public List<AnswerOptionData> answerOptions;
    [TextArea(1, 10)] 
    public string description;

}
