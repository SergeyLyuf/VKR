using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//класс для сохранения параметров в памяти устройства
public static class UserPrefs
{

    private static string SOUND_KEY = "SOUND_ENABLED";
    private static string PROGRESS_KEY = "CURRENT_PROGRESS";

    //сохранение настройки звука
    public static void SetSoundEnabled(bool enabled)
    {
        PlayerPrefs.SetInt(SOUND_KEY, enabled ? 1 : 0);
    }
    
    public static bool IsSoundEnabled()
    {
        return PlayerPrefs.GetInt(SOUND_KEY, 1) == 1;
    }

    //сохранение прогресса в формате JSON
    public static void SetProgress(string json)
    {
        PlayerPrefs.SetString(PROGRESS_KEY, json);
    }
    
    public static string GetProgress()
    {
        return PlayerPrefs.GetString(PROGRESS_KEY, "");
    }
    
    public static bool HasProgress()
    {
        return !string.IsNullOrEmpty(GetProgress());
    }

}
