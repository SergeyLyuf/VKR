using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//используется для форматирования валютных значений при выводе на экран
public static class StringHelper 
{
    
    public static string GetCurrencyValue(string key, int value)
    {
        return key + ": " + GetCurrencyValue(value);
    }
    
    public static string GetCurrencyValue(int value)
    {
        return value.ToString("N0") + " руб.";
    }
    
}
