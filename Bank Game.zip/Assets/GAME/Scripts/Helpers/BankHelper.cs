using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class BankHelper
{

    private static int creditIdentifierCounter;
    
    //возвращает сумму ежемесячного платёжа по кредиту (20% от суммы кредита)
    public static int GetCreditMonthlyPayment(int creditValue)
    {
        return Mathf.RoundToInt(creditValue * 0.2f);
    }
    
    //возвращает уникальный идентификатор для кредита (для поиска кредита в списке)
    public static int GetNewCreditIdentifier()
    {
        creditIdentifierCounter++;
        return creditIdentifierCounter;
    }
   
}
