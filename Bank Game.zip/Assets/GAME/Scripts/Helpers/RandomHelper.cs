using System;
using System.Collections;
using System.Collections.Generic;

//вспомогательный класс для работы с рандомом
public static class RandomHelper 
{
    
    private static Random random = new Random();

    //перемешивает элементы списка любого типа
    public static void ShuffleList<T>(ref List<T> list)
    {
        int n = list.Count;
        while (n > 1) {  
            n--;  
            int k = random.Next(n + 1);  
            T value = list[k];  
            list[k] = list[n];  
            list[n] = value;  
        }  
    }
    
}
