using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class DayCounter
{

    public UnityAction<int> onDayChanged;

    public int day = 1;

    private float dayTime, dayLength;

    private bool counterEnabled = false;

    public void Init(int day, float dayLength)
    {
        this.dayLength = dayLength;
        SetDay(day);
    }

    public void Update()
    {
        if (!counterEnabled)
            return;
        dayTime += Time.deltaTime;
        if (dayTime >= dayLength)
        {
            SetDay(day + 1);
        }
    }

    private void SetDay(int day)
    {
        this.day = day;
        dayTime = 0f;
        onDayChanged?.Invoke(day);
    }

    public void Start()
    {
        counterEnabled = true;
    }
    
    public void Stop()
    {
        counterEnabled = false;
    }
    
 

}
