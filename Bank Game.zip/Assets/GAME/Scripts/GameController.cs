using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class GameController : MonoBehaviour //основной скрипт игры
{

    public UnityAction<int> onBalanceChanged;
    
    public int startBalance = 100000;
    public float timeBetweenDays = 3f;
    public int creditPayDay = 10;
    public int pensionDay = 20;
    public int pensionAmount = 10000;
    public int minDaysBeforeDialog = 3;
    public int maxDaysBeforeDialog = 5;
    public int totalMessagesForWin = 30;
    public DialogData dialogData;

    public MainMenuView mainMenuView;
    public GameView gameView;

    private BankAccount account;
    private DayCounter dayCounter;
    
    private List<MessageData> messages;
    private int messageID = 0;
    private int messagesPassed = 0;
    private MessageData currentMessage;
    private int nextDialogDay = 1;

    private bool isPlaying;
    private int lastPensionDay, lastCreditDay, restoreDay;
    
    // Start is called before the first frame update
    void Start()
    {
        //инициализация объектов и событий для связи объектов
        dayCounter = new DayCounter();
        dayCounter.onDayChanged += OnDayChanged;
        dayCounter.onDayChanged += gameView.dayUI.SetValue;
        account = new BankAccount();
        account.onBalanceUpdated += CheckBalance;
        account.onBalanceUpdated += gameView.bankAccountUI.UpdateBalance;
        account.onCreditAdded += gameView.bankAccountUI.AddCreditUI;
        account.onCreditRemoved += gameView.bankAccountUI.RemoveCreditUI;
        gameView.bankAccountUI.onCreditPayRequest = OnCreditPayRequest;
        messages = dialogData.messages;
        Application.targetFrameRate = 60;
    }

    void Update()
    {
        if (!isPlaying)
            return;
        dayCounter.Update(); //обновление счётчика дней
    }

    //запуск новой игровой сессии
    public void StartGame(bool restoreSession)
    {
        isPlaying = true;
        gameView.ClearAll();
        account.Clear();
        if (restoreSession && UserPrefs.HasProgress()) //восстановление сохранения если оно есть
        {
            var saveData = SaveData.fromJSON(UserPrefs.GetProgress());
            restoreDay = saveData.day;
            lastPensionDay = saveData.lastPensionDay;
            lastCreditDay = saveData.lastCreditDay;
            messagesPassed = saveData.messagesPassed;
            nextDialogDay = saveData.nextMessageDay;
            messageID = saveData.messageID;
            dayCounter.Init(saveData.day, timeBetweenDays);
            account.Restore(saveData.balance, saveData.credits);
        }
        else //сброс значений переменных для новой игры
        {
            lastPensionDay = 0;
            lastCreditDay = 0;
            messagesPassed = 0;
            nextDialogDay = 1;
            messageID = 0;
            dayCounter.Init(1, timeBetweenDays);
            account.Init(startBalance);
        }
    }

    //показывает диалог с сообщением от мошенника и ответами
    private void ShowDialog() 
    {
        currentMessage = GetCurrentMessageData();
        RandomHelper.ShuffleList(ref currentMessage.answerOptions);
        gameView.dialogUI.Show(currentMessage.senderName, currentMessage.message, GetAnswerMessagesFromData(currentMessage), OnAnswerSelected);
    }
    
    //получает ид следующего сообщения из списка в диалоге
    private MessageData GetCurrentMessageData()
    {
        if (messageID >= messages.Count)
        {
            messageID = 0;
            //RandomHelper.ShuffleList(ref messages);
        }
        return messages[messageID];
    }

    //получает массив текстовых ответов в текущем диалоге
    private string[] GetAnswerMessagesFromData(MessageData messageData)
    {
        var answers = new string[messageData.answerOptions.Count];
        for (int i = 0; i < answers.Length; i++)
        {
            answers[i] = messageData.answerOptions[i].answerText;
        }
        return answers;
    }

    //вызывается при выборе ответа игроком
    private void OnAnswerSelected(int index)
    {
        var answerOption = currentMessage.answerOptions[index]; 
        switch (answerOption.stealType) //проверка типа выбранного ответа
        {
            case StealType.Withdraw: //списать деньги с баланса
                account.Pay(answerOption.stealValue);
                gameView.toastMessage.Show("С Вашего аккаунта украли " + StringHelper.GetCurrencyValue(answerOption.stealValue), ToastMessage.ToastType.Negative);
                break;
            case StealType.Credit: //взять кредит
                account.AddCredit(answerOption.stealValue);
                gameView.toastMessage.Show("На Вас оформили кредит в размере " + StringHelper.GetCurrencyValue(answerOption.stealValue), ToastMessage.ToastType.Negative);
                break;
        }
        if (!isPlaying) //если игра окончена - не показывать окно с пояснением после ответа
            return;
        gameView.popupMessage.Show(currentMessage.description, () =>
        {
            messageID++;
            messagesPassed++;
            if (messagesPassed >= totalMessagesForWin) //если игрок просмотрел достаточно сообщений - он прошёл игру
            {
                gameView.gameOverPopup.Show("Поздравляем!\nВы успешно завершили игру.", RestartGame, ExitToMenu);;
            }
            else //задаём следующий день когда покажется сообщение и запускаем счётчик дней
            {
                nextDialogDay = GetNextDialogDay();
                dayCounter.Start();
            }
        });
    }

    //вызывается при нажатии кнопки для погашения кредита
    private void OnCreditPayRequest(CreditInfo credit)
    {
        if (account.HasAmount(credit.totalValue)) //если достаточно средств - погашаем кредит 
        {
            account.Pay(credit.totalValue);
            account.RemoveCredit(credit);
            gameView.toastMessage.Show("Вы погасили кредит в размере " + StringHelper.GetCurrencyValue(credit.totalValue), ToastMessage.ToastType.Positive);
        }
        else
        {
            gameView.toastMessage.Show("Недостаточно средств для погашения кредита", ToastMessage.ToastType.Negative);
        }
    }

    //вызывается при наступлении нового дня
    private void OnDayChanged(int day)
    {
        dayCounter.Stop(); //останавливаем счётчик дней для проверки событий текущего дня
        StartCoroutine(DayTasksCoroutine(day));
    }

    //проверяет события текущего дня
    private IEnumerator DayTasksCoroutine(int day)
    {
        bool hasTasks = false;
        if (CanGetPension(day)) //если это день пенсии - игрок получает деньги
        {
            hasTasks = true;
            account.Receive(pensionAmount);
            gameView.toastMessage.Show("Вы получили пенсию в размере " + StringHelper.GetCurrencyValue(pensionAmount), ToastMessage.ToastType.Positive);
            yield return new WaitForSeconds(1f);
        }
        if (account.HasCredits() && ShouldPayCredit(day)) //если есть кредиты и это день платежа - оплачиваем активные кредиты 
        {
            hasTasks = true;
            foreach (var credit in account.GetCredits())
            {
                account.Pay(credit.monthlyPayment);
                gameView.toastMessage.Show("Списали платёж по кредиту в размере" + StringHelper.GetCurrencyValue(credit.monthlyPayment), ToastMessage.ToastType.Negative);
                yield return new WaitForSeconds(0.5f);
            }
        }
        if (day == nextDialogDay) //если это день следующего показа диалога - показываем
        {
            ShowDialog();
        }
        else 
        {
            if (!hasTasks)
                gameView.toastMessage.Show("В этот день ничего не произошло", ToastMessage.ToastType.Neutral);
            dayCounter.Start(); //запуск счётчика дней
        }
    }

    //проверяет может ли игрок получить пенсию в этот день
    private bool CanGetPension(int day)
    {
        if (day == restoreDay) //если это первый день после загрузки сохранения - пенсия уже была получена
            return false;
        if (lastPensionDay > 0 && day - lastPensionDay < 30) //не прошло 30 дней с прошлой пенсии
            return false;
        return day % pensionDay == 0; //текущий день делится на 20 - это день пенсии
    }
    
    private bool ShouldPayCredit(int day)
    {
        if (day == restoreDay) //если это первый день после загрузки сохранения - платёж уже был
            return false;
        if (lastCreditDay > 0 && day - lastCreditDay < 30) //не прошло 30 дней с прошлого платежа
            return false;
        return day % creditPayDay == 0; //текущий день делится на 10 - это день платежа
    }

    //возвращает следующий день для показа диалога случайным образом
    private int GetNextDialogDay()
    {
        return dayCounter.day + Random.Range(minDaysBeforeDialog, maxDaysBeforeDialog);
    }

    //вызывается при обновлении баланса
    private void CheckBalance(int balance)
    {
        if (balance <= 0) //если баланс отрицательный - игра окончена
        {
            dayCounter.Stop();
            isPlaying = false;
            gameView.gameOverPopup.Show("Игра завершена.\nУ вас отрицательный баланс.", RestartGame, ExitToMenu);
        }
    }

    //перезапуск игры с начала
    private void RestartGame()
    {
        StartGame(false);
    }
    
    //выход в главное меню
    public void ExitToMenu()
    {
        SaveGame();
        mainMenuView.Show();
        gameView.Hide();
    }

    //сохранение прогресса игры в JSON
    private void SaveGame()
    {
        if (!isPlaying)
            return;
        var saveData = new SaveData()
        {
            balance = account.GetBalance(),
            credits = account.GetCredits(),
            day = dayCounter.day,
            nextMessageDay = nextDialogDay,
            messagesPassed = messagesPassed,
            lastPensionDay = lastPensionDay,
            lastCreditDay = lastCreditDay,
            messageID = messageID
        };
        UserPrefs.SetProgress(saveData.toJSON());
    }

    //при закрытия приложения игра сохраняется
    void OnDestroy()
    {
        SaveGame();
    }
}
