using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

//окно с сообщением от мошенника и ответами
public class DialogUI : MonoBehaviour
{

    public TMP_Text senderText, messageText;
    public RectTransform messageRoot, answersParent;
    public AnswerButton answerButtonPrefab;
    public VerticalLayoutGroup answerButtonsGroup;

    public float showElementAnimationTime = 0.35f, hideElementAnimationTime = 0.35f;
    public float delayBetweenButtonAppear = 0.35f;
    public float elementHorizontalOffset = 200f;

    private float defaultMessagePosition;
    private List<AnswerButton> answerButtons = new List<AnswerButton>();
    private float answerButtonPositionX;

    private bool isVisible = false;
    
    void Start()
    {
        defaultMessagePosition = messageRoot.position.x;
    }

    //моментальное скрытие окна при выходе или перезапуске игры
    public void Reset()
    {
        Clear();
        isVisible = false;
        messageRoot.GetComponent<CanvasGroup>().alpha = 0f;
    }
    
    private void Clear()
    {
        for (int i = 0; i < answersParent.childCount; i++)
        {
            Destroy(answersParent.GetChild(i).gameObject);
        }
        answerButtons.Clear();
    }

    //появление окна с диалогом
    public void Show(string senderName, string message, string[] answers, UnityAction<int> onAnswerSelected)
    {
        if (isVisible)
            return;
        isVisible = true;
        senderText.text = senderName;
        messageText.text = message;
        Clear();
        answerButtonsGroup.enabled = true;
        for (int i = 0; i < answers.Length; i++)
        {
            int id = i;
            var answerButton = Instantiate(answerButtonPrefab, answersParent);
            answerButton.Init(answers[i], () =>
            {
                SoundController.Instance?.PlayClickSound();
                Hide(() =>
                {
                    onAnswerSelected?.Invoke(id);
                });
            });
            answerButton.SetAlpha(0f);
            answerButtons.Add(answerButton);
        }

        StartCoroutine(ShowDialogAnimation());
    }

    //скрытие окна с диалогом
    public void Hide(UnityAction onComplete)
    {
        if (!isVisible)
            return;
        isVisible = false;
        foreach (var answerButton in answerButtons)
        {
            answerButton.GetCanvasGroup().blocksRaycasts = false;
        }
        StartCoroutine(HideDialogAnimation(onComplete));
    }

    private IEnumerator ShowDialogAnimation()
    {
        yield return StartCoroutine(ElementAnimation(messageRoot, true, defaultMessagePosition, -1f));
        answerButtonPositionX = answerButtons[0].GetRectTransform().position.x;
        answerButtonsGroup.enabled = false;
        for (var i = 0; i < answerButtons.Count; i++)
        {
            var answerButton = answerButtons[i];
            StartCoroutine(ElementAnimation(answerButton.GetRectTransform(), true, answerButtonPositionX,1f));
            if (i < answerButtons.Count - 1)
                yield return new WaitForSeconds(delayBetweenButtonAppear);
        }
    }
    
    private IEnumerator HideDialogAnimation(UnityAction onComplete)
    {
        StartCoroutine(ElementAnimation(messageRoot, false, defaultMessagePosition, -1f));
        answerButtonPositionX = answerButtons[0].GetRectTransform().position.x;
        answerButtonsGroup.enabled = false;
        for (var i = 0; i < answerButtons.Count; i++)
        {
            var answerButton = answerButtons[i];
            StartCoroutine(ElementAnimation(answerButton.GetRectTransform(), false, answerButtonPositionX,1f));
            if (i < answerButtons.Count - 1)
                yield return new WaitForSeconds(delayBetweenButtonAppear);
        }
        onComplete?.Invoke();
    }

    private IEnumerator ElementAnimation(RectTransform element, bool show, float defaultPosition, float offsetSign)
    {
        CanvasGroup canvasGroup = element.GetComponent<CanvasGroup>();
        float shiftPosition = defaultPosition + elementHorizontalOffset * offsetSign;
        SetPosition(ref element, show ? shiftPosition : defaultMessagePosition);
        canvasGroup.alpha = show ? 0f : 1f;
        for (float t = 0f; t < showElementAnimationTime; t += Time.deltaTime)
        {
            float nt = t / showElementAnimationTime;
            if (!show)
                nt = 1f - nt;
            float pos = Mathf.LerpUnclamped(shiftPosition, defaultMessagePosition, EaseFunctions.OutBack(nt));
            SetPosition(ref element, pos);
            canvasGroup.alpha = Mathf.Lerp(0f, 1f, nt);
            yield return null;
        }
        SetPosition(ref element, show ? defaultMessagePosition : shiftPosition);
        canvasGroup.alpha = show ? 1f : 0f;
    }

    private void SetPosition(ref RectTransform element, float x)
    {
        Vector3 position = element.position;
        position.x = x;
        element.position = position;
    }

}
