using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class CreditTab : MonoBehaviour
{

    public TMP_Text totalText, paymentText;
    public Button payButton;

    private int id;

    public void Init(int id, int totalValue, int paymentValue, UnityAction onPay)
    {
        this.id = id;
        totalText.text = StringHelper.GetCurrencyValue("Кредит", totalValue);
        paymentText.text = StringHelper.GetCurrencyValue("Платёж", paymentValue);
        payButton.onClick.RemoveAllListeners();
        payButton.onClick.AddListener(onPay);
    }

    public int GetID()
    {
        return id;
    }

}
