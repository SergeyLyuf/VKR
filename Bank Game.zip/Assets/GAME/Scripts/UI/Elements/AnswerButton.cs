using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class AnswerButton : MonoBehaviour
{
    public TMP_Text headerText;
    public Button button;
    public CanvasGroup canvasGroup;
    public RectTransform root;

    private UnityAction onClick;

    public void Init(string text, UnityAction onClick)
    {
        headerText.text = text;
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(onClick);
    }

    public RectTransform GetRectTransform()
    {
        return root;
    }

    public void SetAlpha(float a)
    {
        GetComponent<CanvasGroup>().alpha = a;
    }

    public CanvasGroup GetCanvasGroup()
    {
        return canvasGroup;
    }
}
