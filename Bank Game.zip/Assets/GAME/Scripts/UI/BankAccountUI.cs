using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

public class BankAccountUI : MonoBehaviour
{

    public UnityAction<CreditInfo> onCreditPayRequest;

    public TMP_Text balanceText;

    public RectTransform creditsParent;
    public CreditTab creditTabPrefab;
    
    private List<CreditTab> activeCreditTabs = new List<CreditTab>();
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void UpdateBalance(int value)
    {
        balanceText.text = StringHelper.GetCurrencyValue("Баланc", value);
    }

    public void AddCreditUI(CreditInfo credit)
    {
        var creditTab = Instantiate(creditTabPrefab, creditsParent);
        creditTab.Init(credit.id, credit.totalValue, credit.monthlyPayment, () =>
        {
            SoundController.Instance?.PlayClickSound();
            onCreditPayRequest?.Invoke(credit);
        });
        activeCreditTabs.Add(creditTab);
    }

    public void RemoveCreditUI(CreditInfo credit)
    {
        int index = activeCreditTabs.FindIndex(tab => tab.GetID() == credit.id);
        if (index >= 0)
        {
            var creditTab = activeCreditTabs[index];
            activeCreditTabs.RemoveAt(index);
            Destroy(creditTab.gameObject);
        }
    }

    public void Clear()
    {
        for (int i = activeCreditTabs.Count - 1; i >= 0; i--)
        {
            Destroy(activeCreditTabs[i].gameObject);
        }
        activeCreditTabs.Clear();
    }
    
}
