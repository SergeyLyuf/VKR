using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class PopupMessage : MonoBehaviour
{
    
    public CanvasGroup canvasGroup;
    public Image backgroundImage;
    public RectTransform messageWindow;
    public TMP_Text messageText;

    public float animationTime = 0.35f;
    public float backgroundAlpha = 0.5f;

    private UnityAction onClose;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void Show(string message, UnityAction onClose)
    {
        messageText.text = message;
        this.onClose = onClose;
        LayoutRebuilder.ForceRebuildLayoutImmediate(messageWindow);
        StartCoroutine(PopupAnimation(true));
    }


    public void OnClose()
    {
        StartCoroutine(PopupAnimation(false, onClose));
    }

    protected IEnumerator PopupAnimation(bool show, UnityAction onComplete = null)
    {
        if (show)
        {
            SetBackgroundAlpha(0f);
            messageWindow.localScale = Vector3.zero;
            canvasGroup.alpha = 1f;
        }
        canvasGroup.blocksRaycasts = false;
        for (float t = 0f; t < animationTime; t += Time.deltaTime)
        {
            float nt = t / animationTime;
            if (!show)
                nt = 1f - nt;
            float easeValue = show ? EaseFunctions.OutBack(nt) : EaseFunctions.OutBack(nt);
            messageWindow.localScale = Vector3.LerpUnclamped(Vector3.zero, Vector3.one, easeValue);
            SetBackgroundAlpha(Mathf.Lerp(0f, backgroundAlpha, nt));
            yield return null;
        }
        messageWindow.localScale = show ? Vector3.one : Vector3.zero;
        SetBackgroundAlpha(show ? backgroundAlpha : 0f);
        if (show)
            canvasGroup.blocksRaycasts = true;
        else
            canvasGroup.alpha = 0f;
        onComplete?.Invoke();
    }

    private void SetBackgroundAlpha(float a)
    {
        Color c = backgroundImage.color;
        c.a = a;
        backgroundImage.color = c;
    }

    public void Clear()
    {
        canvasGroup.alpha = 0f;
        canvasGroup.blocksRaycasts = false;
    }
    
}
