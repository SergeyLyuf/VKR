using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ToastMessage : MonoBehaviour
{

    public List<ToastStyle> styles;
    public RectTransform root, startPoint;
    public TMP_Text toastMessagePrefab;
    public float floatingDistance = 50f;
    public float floatingTime = 2f;
    public float fadeTime = 1f;
    
    [Serializable]
    public class ToastStyle
    {
        public ToastType type;
        public Color textColor = Color.black;
    }
    
    public enum ToastType
    {
        Positive, Negative, Neutral
    }

    public void Show(string message, ToastType type)
    {
        StartCoroutine(ShowCoroutine(message, type));
    }

    private IEnumerator ShowCoroutine(string message, ToastType type)
    {
        var style = styles.Find(_style => _style.type == type);
        var toast = Instantiate(toastMessagePrefab, root);
        toast.text = message;
        toast.color = style.textColor;
        toast.rectTransform.position = startPoint.position;
        Vector3 endPosition = startPoint.position + Vector3.up * floatingDistance;
        for (float t = 0f; t < floatingTime; t += Time.deltaTime)
        {
            float nt = t / floatingTime;
            toast.rectTransform.position = Vector3.Lerp(startPoint.position, endPosition, nt);
            if (floatingTime - t <= fadeTime)
            {
                float alphaTime = (floatingTime - t) / fadeTime;
                toast.alpha = Mathf.Lerp(0f, 1f, alphaTime);
            }
            yield return null;
        }
        toast.alpha = 0f;
        Destroy(toast.gameObject);
    }
   
}
