using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class GameOverPopup : PopupMessage
{

    private UnityAction onRestart, onExit;
    
    public void Show(string message, UnityAction onRestart, UnityAction onExit)
    {
        messageText.text = message;
        this.onRestart = onRestart;
        this.onExit = onExit;
        StartCoroutine(PopupAnimation(true));
    }

    public void OnRestart()
    {
        StartCoroutine(PopupAnimation(false, onRestart));
    }
    
    public void OnExit()
    {
        StartCoroutine(PopupAnimation(false, onExit));
    }
    
}
