using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DayUI : MonoBehaviour
{

    public TMP_Text dayText;
    public float animationTime = 0.35f;

    private Coroutine animationCoroutine;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void SetValue(int day)
    {
        if (day == 1)
        {
            SetDayText(day);
        }
        else
        {
            if (animationCoroutine != null)
                StopCoroutine(animationCoroutine);
            animationCoroutine = StartCoroutine(AnimationCoroutine(day));
        }
    }

    private IEnumerator AnimationCoroutine(int day)
    {
        dayText.rectTransform.localScale = Vector3.one;
        bool dayChanged = false;
        for (float t = 0f; t < animationTime; t += Time.deltaTime)
        {
            float nt = t / animationTime;
            if (nt < 0.5f)
            {
                dayText.rectTransform.localScale = Vector3.Lerp(Vector3.one, Vector3.zero, nt * 2f);
            }
            else
            {
                if (!dayChanged && nt >= 0.5f)
                {
                    SetDayText(day);
                    dayChanged = true;
                }
                float lerpValue = EaseFunctions.OutBack((nt - 0.5f) * 2f);
                dayText.rectTransform.localScale = Vector3.LerpUnclamped(Vector3.zero, Vector3.one, lerpValue);
            }
            
            
            /*float angle = Mathf.Lerp(0, 360f, nt);
            dayText.rectTransform.rotation = Quaternion.Euler(angle, 0f, 0f);
            if (!dayChanged && nt >= 0.5f)
            {
                SetDayText(day);
                dayChanged = true;
            }*/
            yield return null;
        }
        dayText.rectTransform.rotation = Quaternion.Euler(0, 0, 0);
        animationCoroutine = null;
    }
    
    private void SetDayText(int day)
    {
        dayText.text = "ДЕНЬ " + day.ToString();
    }
}
