using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

//интерфейс главного меню
public class MainMenuView : UIView
{
    
    public GameObject continueButton;
    public Button soundButton;
    public Sprite soundOnSprite, soundOffSprite;
    
    // Start is called before the first frame update
    void Start()
    {
        InitButtons();
    }

    public override void Show(float delay = 0)
    {
        base.Show(delay);
        InitButtons();
    }

    //выход из приложения
    public void ExitButtonEvent()
    {
        Application.Quit();
    }

    private void InitButtons()
    {
        continueButton.SetActive(UserPrefs.HasProgress()); //кнопка Продолжить показывается только если есть сохранение
        soundButton.image.sprite = UserPrefs.IsSoundEnabled() ? soundOnSprite : soundOffSprite; //изменение спрайта кнопки для переключения звука
    }

    //включение/выключение звука
    public void ToggleSoundFX()
    {
        UserPrefs.SetSoundEnabled(!UserPrefs.IsSoundEnabled());
        soundButton.image.sprite = UserPrefs.IsSoundEnabled() ? soundOnSprite : soundOffSprite;
        SoundController.Instance?.RefreshSoundState();
    }
    
}
