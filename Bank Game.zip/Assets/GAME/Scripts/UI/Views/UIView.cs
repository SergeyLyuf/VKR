using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//базовый класс экрана интерфейса
public class UIView : MonoBehaviour
{

    public float fadeTime = 0.3f;
    
    private CanvasGroup canvasGroup;

    void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
    }
    
    public virtual void Show(float delay = 0f)
    {
        if (canvasGroup.alpha != 0f)
            return;
        StartCoroutine(ShowCoroutine(delay));
    }
    
    public virtual void Hide()
    {
        if (canvasGroup.alpha != 1f)
            return;
        StartCoroutine(HideCoroutine());
    }
    
    private IEnumerator ShowCoroutine(float delay = 0f)
    {
        if (delay > 0f)
            yield return new WaitForSeconds(delay);
        for (float t = 0f; t < fadeTime; t += Time.deltaTime)
        {
            float nt = t / fadeTime;
            canvasGroup.alpha = nt;
            yield return null;
        }
        canvasGroup.alpha = 1f;
        canvasGroup.blocksRaycasts = true;
    }
    
    private IEnumerator HideCoroutine()
    {
        canvasGroup.blocksRaycasts = false;
        for (float t = 0f; t < fadeTime; t += Time.deltaTime)
        {
            float nt = t / fadeTime;
            canvasGroup.alpha = 1f - nt;
            yield return null;
        }
        canvasGroup.alpha = 0f;
    }

}
