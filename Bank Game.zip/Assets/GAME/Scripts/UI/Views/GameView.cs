using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

//интерфейс игрового экрана
public class GameView : UIView
{

    public BankAccountUI bankAccountUI; //данные UI банковского аккаунта
    public DialogUI dialogUI; //данные диалога с ответами
    public ToastMessage toastMessage; //всплывающий текст
    public PopupMessage popupMessage; //всплывающее окно с пояснением
    public DayUI dayUI; //анимированный счётчик дней
    public GameOverPopup gameOverPopup; //меню окончания игры
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    //очистка всех элементов интерфейса (используется при старте новой игры)
    public void ClearAll()
    {
        dialogUI.Reset();
        bankAccountUI.Clear();
        popupMessage.Clear();
    }

   
}
