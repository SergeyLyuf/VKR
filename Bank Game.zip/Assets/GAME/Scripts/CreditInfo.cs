using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class CreditInfo //данные о кредите (идентификатор, сумма кредита ежемесячны платёж)
{

    public int id, totalValue, monthlyPayment;
    
    public CreditInfo(int totalValue)
    {
        this.totalValue = totalValue;
        id = BankHelper.GetNewCreditIdentifier();
        monthlyPayment = BankHelper.GetCreditMonthlyPayment(totalValue);
    }
    
}
