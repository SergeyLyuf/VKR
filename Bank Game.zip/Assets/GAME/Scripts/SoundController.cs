using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundController : MonoBehaviour
{

    public static SoundController Instance;

    public AudioSource clickSound;

    private bool soundEnabled;
    
    void Awake()
    {
        Init();
    }

    private void Init()
    {
        Instance = this;
        RefreshSoundState();
    }

    public void RefreshSoundState()
    {
        soundEnabled = UserPrefs.IsSoundEnabled();
    }

    private void PlaySound(AudioSource sound)
    {
        if (soundEnabled && sound != null && sound.clip != null)
            sound.Play();
    }

    public void PlayClickSound()
    {
        PlaySound(clickSound);
    }
    
}
